<body>
  <?php
  include "header.php";
 
  ?>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/cs03.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong>Explore <br></strong> your faviourate event</h1>
            <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Fest starts in</p>
            <div>
            <h1 class="mb-4"  data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong id="demo"><br></strong></h1>
            
            </div>
            
            
            </div>
          </div>
        </div>
      </div>
    </div>

    
    
    <section class=" bg-light" id="events">
    	<div class="container" id="0">
    		<div class="row justify-content-start mb-5 pb-3">
             <div class="col-md-7 heading-section ftco-animate">

            <h2 class="mb-4"><strong>Successfully Registered</strong> <br>  Welcome To Ilahia College of Engineering and Technology</h2>
          </div>
        </div>  
    		
    					
				    </div>
    			</div>
    		</div>
    	</div>
    </section>
    
    

    


   

   

    

    
		
		

    
  
                                    