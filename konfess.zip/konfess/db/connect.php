<?php

$servername = "15.207.93.86";
$username = "root";
$password = "Hijas@1234";
$db = "events";

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
