
<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
include "db/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include "includes/header.php";
include "cssjs/css.php";?>
<!-- END nav -->
    
<div class="hero-wrap js-fullheight" style="background-image: url('images/cs03.jpg');">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
      <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
        <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong>Explore <br></strong> your faviourate event</h1>
        <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Fest starts in</p>
        <div>
        <h1 class="mb-4"  data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong id="demo"><br></strong></h1>
        
        </div>
        
        
        </div>
      </div>
    </div>
  </div>
</div>



<section class=" bg-light" id="events">
    <div class="container" id="0">
        <div class="row justify-content-start mb-5 pb-3">
         <div class="col-md-7 heading-section ftco-animate">

         <u><h1>Rules for REELISTIC</h1></u>
        <br><h4> Cordinator :- Hijas (+91-9497844374)</h4>
        
        
        <h4>Reels Shooting<h4>
            <br><ul>
         <li><p style="font-size:15px">Minimum 30 seconds (maximum 60 seconds)</p></li>
         <li><p style="font-size:15px">Must be inside college campus</p></li>
         <li><p style="font-size:15px">only three members needed  </p></li>
         <li><p style="font-size:15px">must be an orginal creation can be inspired</p></li>
         <li><p style="font-size:15px">video must be shoot in vertical direction</p></li>
         <li><p style="font-size:15px">should submit the video with in 3hour </p></li>
         <li><p style="font-size:15px">contents or Theme will be given at the venue</p></li>
         <li><p style="font-size:15px">Any kind of malpractice will lead to disqualifiation</p></li>
         <li><p style="font-size:15px">the Descision of judging panel will be final and will not be subjected to any change</p></li>
</ul>


      </div>
    </div>  
        
   <center> <a href="register.php?event_id=1" class="btn btn-info" role="button">Register Now</a></center>
                </div>
            </div>
        </div>
    </div>
</section>






include "includes/footer.php";
?>
  
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <?php
  include "./cssjs/js.php";
  ?>
  </body>  
</html>