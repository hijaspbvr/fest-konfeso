
<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
include "db/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include "includes/header.php";
include "cssjs/css.php";?>
<!-- END nav -->
    
<div class="hero-wrap js-fullheight" style="background-image: url('images/cs03.jpg');">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
      <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
        <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong>Explore <br></strong> your faviourate event</h1>
        <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Fest starts in</p>
        <div>
        <h1 class="mb-4"  data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong id="demo"><br></strong></h1>
        
        </div>
        
        
        </div>
      </div>
    </div>
  </div>
</div>



<section class=" bg-light" id="events">
    <div class="container" id="0">
        <div class="row justify-content-start mb-5 pb-3">
         <div class="col-md-7 heading-section ftco-animate">

         <u><h1>Rules for App Monsters(coding)</h1></u>
        <br><h4> Cordinator :- Hijas (+91-9497844374)</h4>
        <h3> Total - 2 Rounds<h3>
        
        <h4> First Round- Offline Test<h4>
            <br><ul>
         <li><p style="font-size:15px">The contestants will be given an offline exam for 30 minutes to test their language expertise</p></li>
         <li><p style="font-size:15px">questions will be basd on C or C++ </p></li>
         <li><p style="font-size:15px">Each correct answer carries 2 marks </p></li>
         <li><p style="font-size:15px">Each wrong answer will reduce 1 mark from obtained marks</p></li>
</ul>
        <p>After the first round,the top 6 Teams will go the second round</p>

        <h4> Second Round- Machine Test<h4>
        <br><ul>
         <li><p style="font-size:15px">The contestants will be given an machine Test for 1 hour to test their language expertise </p></li>
         <li><p style="font-size:15px">questions will be based on C or C++ </p></li>
         <li><p style="font-size:15px">Systems will be provided "</p> </li>
         <li><p style="font-size:15px">The participants will not be allowed to use mobile phones or other electronic gadgets </p></li>
         <li><p style="font-size:15px">Any kind of malpractice will lead to disqualifiation</p></li>
         <li><p style="font-size:15px">the Descision of judging panel will be final and will not be subjected to any change</p></li>
</ul>


      </div>
    </div>  
        
   <center> <a href="register.php?event_id=1" class="btn btn-info" role="button">Register Now</a></center>
                </div>
            </div>
        </div>
    </div>
</section>






include "includes/footer.php";
?>
  
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <?php
  include "./cssjs/js.php";
  ?>
  </body>  
</html>