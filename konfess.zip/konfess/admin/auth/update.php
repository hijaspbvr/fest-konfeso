<?php 
include "db/connect.php";
if(isset($_GET['id'])){ $id= $_GET['id'];
 $sql = "UPDATE `participants` 
		SET status='Reported' 
        WHERE p_id = $id";
		
		if(mysqli_query($con,$sql)){
			echo "<script>alert(Successfully Registered);</script>";
			echo "<script> location.href='index.php'; </script>";
            exit;} }
            else { echo "failed"; } ?>